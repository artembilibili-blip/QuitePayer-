package com.quietplayer

import android.content.ComponentName
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.documentfile.provider.DocumentFile
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import com.google.common.util.concurrent.ListenableFuture
import android.media.MediaMetadataRetriever
import java.util.Locale

class MainActivity : ComponentActivity() {
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var mediaController: MediaController? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync()
        controllerFuture?.addListener({
            mediaController = controllerFuture?.get()
        }, mainExecutor)

        setContent {
            QuietPlayerApp(
                getController = { mediaController },
                onFolderSelected = { uri ->
                    contentResolver.takePersistableUriPermission(
                        uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                    getSharedPreferences("quiet_player", MODE_PRIVATE)
                        .edit().putString("folder_uri", uri.toString()).apply()
                },
                savedFolder = getSharedPreferences("quiet_player", MODE_PRIVATE)
                    .getString("folder_uri", null)?.let(Uri::parse)
            )
        }
    }

    override fun onDestroy() {
        controllerFuture?.let { MediaController.releaseFuture(it) }
        super.onDestroy()
    }
}

private enum class LibraryTab { Albums, Artists, Tracks }

@Composable
private fun QuietPlayerApp(
    getController: () -> MediaController?,
    onFolderSelected: (Uri) -> Unit,
    savedFolder: Uri?
) {
    val context = LocalContext.current
    var dark by remember { mutableStateOf(true) }
    var folderUri by remember { mutableStateOf(savedFolder) }
    var tracks by remember { mutableStateOf<List<Track>>(emptyList()) }
    var tab by remember { mutableStateOf(LibraryTab.Albums) }
    var selectedTrack by remember { mutableStateOf<Track?>(null) }
    var isPlaying by remember { mutableStateOf(false) }
    var position by remember { mutableLongStateOf(0L) }
    var duration by remember { mutableLongStateOf(0L) }
    var status by remember { mutableStateOf("Выбери папку с музыкой") }
    var loading by remember { mutableStateOf(false) }

    val colors = if (dark) darkColorScheme(
        primary = androidx.compose.ui.graphics.Color(0xFFC6B8FF),
        background = androidx.compose.ui.graphics.Color(0xFF111114),
        surface = androidx.compose.ui.graphics.Color(0xFF1B1B20)
    ) else lightColorScheme(
        primary = androidx.compose.ui.graphics.Color(0xFF51458A),
        background = androidx.compose.ui.graphics.Color(0xFFF7F6FA),
        surface = androidx.compose.ui.graphics.Color(0xFFFFFFFF)
    )

    val folderPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        if (uri != null) {
            folderUri = uri
            onFolderSelected(uri)
        }
    }

    fun loadFolder(uri: Uri) {
        loading = true
        status = "Сканирую папку…"
        // Scan and read basic metadata away from the UI thread.
        kotlinx.coroutines.MainScope().launch {
            val found = withContext(Dispatchers.IO) {
                val root = DocumentFile.fromTreeUri(context, uri)
                val audioExtensions = setOf("mp3", "m4a", "aac", "flac", "wav", "ogg", "opus", "3gp", "amr", "m4b")
                val docs = mutableListOf<DocumentFile>()
                fun walk(dir: DocumentFile, depth: Int) {
                    if (depth > 8) return
                    dir.listFiles().forEach { f ->
                        if (f.isDirectory) walk(f, depth + 1)
                        else {
                            val ext = f.name?.substringAfterLast('.', "")?.lowercase(Locale.ROOT)
                            if (ext in audioExtensions) docs.add(f)
                        }
                    }
                }
                if (root != null) walk(root, 0)
                docs.map { doc ->
                    val retriever = MediaMetadataRetriever()
                    var title = doc.name?.substringBeforeLast('.') ?: "Без названия"
                    var artist = "Неизвестный исполнитель"
                    var album = "Без альбома"
                    var length = 0L
                    try {
                        retriever.setDataSource(context, doc.uri)
                        title = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE) ?: title
                        artist = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST) ?: artist
                        album = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM) ?: album
                        length = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                    } catch (_: Exception) {
                    } finally {
                        try { retriever.release() } catch (_: Exception) {}
                    }
                    Track(doc.uri, title, artist, album, length)
                }.sortedWith(compareBy(String.CASE_INSENSITIVE_ORDER) { it.title })
            }
            tracks = found
            loading = false
            status = if (found.isEmpty()) "В этой папке аудиофайлы не найдены" else "Найдено треков: ${found.size}"
        }
    }

    LaunchedEffect(folderUri) {
        if (folderUri != null) loadFolder(folderUri!!)
    }

    DisposableEffect(getController()) {
        val controller = getController()
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) { isPlaying = playing }
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                val id = mediaItem?.mediaId
                selectedTrack = tracks.firstOrNull { it.uri.toString() == id } ?: selectedTrack
                duration = controller?.duration?.coerceAtLeast(0L) ?: 0L
            }
            override fun onPlaybackStateChanged(playbackState: Int) {
                duration = controller?.duration?.coerceAtLeast(0L) ?: 0L
            }
        }
        controller?.addListener(listener)
        onDispose { controller?.removeListener(listener) }
    }

    LaunchedEffect(isPlaying, selectedTrack) {
        while (true) {
            val c = getController()
            if (c != null) {
                position = c.currentPosition.coerceAtLeast(0L)
                duration = c.duration.coerceAtLeast(0L)
            }
            kotlinx.coroutines.delay(500)
        }
    }

    MaterialTheme(colorScheme = colors) {
        Surface(Modifier.fillMaxSize(), color = colors.background) {
            Column(Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(top = 18.dp, bottom = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("quiet player", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.SemiBold)
                        Text("Твоя музыка. Ничего лишнего.", style = MaterialTheme.typography.bodySmall, color = colors.onSurfaceVariant)
                    }
                    IconButton(onClick = { dark = !dark }) {
                        Icon(if (dark) Icons.Default.LightMode else Icons.Default.DarkMode, contentDescription = "Сменить тему")
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { folderPicker.launch(folderUri) }) {
                        Icon(Icons.Default.FolderOpen, null, Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(if (folderUri == null) "Выбрать папку" else "Папка")
                    }
                    OutlinedButton(onClick = { folderUri?.let { loadFolder(it) } }, enabled = folderUri != null && !loading) {
                        Icon(Icons.Default.Refresh, null, Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Обновить")
                    }
                }
                Spacer(Modifier.height(12.dp))
                if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())
                Text(status, style = MaterialTheme.typography.bodySmall, color = colors.onSurfaceVariant, modifier = Modifier.padding(vertical = 8.dp))
                SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                    LibraryTab.entries.forEachIndexed { index, item ->
                        SegmentedButton(
                            selected = tab == item,
                            onClick = { tab = item },
                            shape = SegmentedButtonDefaults.itemShape(index, LibraryTab.entries.size)
                        ) { Text(when (item) { LibraryTab.Albums -> "Альбомы"; LibraryTab.Artists -> "Артисты"; LibraryTab.Tracks -> "Треки" }) }
                    }
                }
                Spacer(Modifier.height(8.dp))
                val displayTracks = when (tab) {
                    LibraryTab.Tracks -> tracks
                    LibraryTab.Artists -> tracks.distinctBy { it.artist }.sortedBy { it.artist.lowercase() }
                    LibraryTab.Albums -> tracks.distinctBy { it.album + "|" + it.artist }.sortedBy { it.album.lowercase() }
                }
                if (displayTracks.isEmpty() && !loading) {
                    Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.MusicNote, null, Modifier.size(42.dp), tint = colors.onSurfaceVariant)
                            Spacer(Modifier.height(10.dp))
                            Text(if (folderUri == null) "Выбери одну папку с музыкой" else "Здесь пока тихо")
                        }
                    }
                } else {
                    LazyColumn(Modifier.weight(1f).fillMaxWidth(), contentPadding = PaddingValues(bottom = 12.dp)) {
                        itemsIndexed(displayTracks, key = { _, track -> track.uri.toString() }) { index, track ->
                            Row(
                                Modifier.fillMaxWidth().clickable {
                                    selectedTrack = track
                                    val controller = getController()
                                    if (controller != null) {
                                        val queue = tracks.map { it.toMediaItem() }
                                        controller.setMediaItems(queue, tracks.indexOf(track), 0L)
                                        controller.prepare()
                                        controller.play()
                                    }
                                }.padding(vertical = 10.dp, horizontal = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(shape = RoundedCornerShape(10.dp), color = colors.surface, modifier = Modifier.size(46.dp)) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(when (tab) {
                                            LibraryTab.Albums -> Icons.Default.Album
                                            LibraryTab.Artists -> Icons.Default.Person
                                            LibraryTab.Tracks -> Icons.Default.MusicNote
                                        }, null, tint = colors.onSurfaceVariant)
                                    }
                                }
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(
                                        when (tab) {
                                            LibraryTab.Albums -> track.album
                                            LibraryTab.Artists -> track.artist
                                            LibraryTab.Tracks -> track.title
                                        },
                                        maxLines = 1, fontWeight = FontWeight.Medium
                                    )
                                    Text(
                                        when (tab) {
                                            LibraryTab.Albums -> track.artist
                                            LibraryTab.Artists -> "${tracks.count { it.artist == track.artist }} трек(ов)"
                                            LibraryTab.Tracks -> "${track.artist} · ${track.album}"
                                        },
                                        maxLines = 1, style = MaterialTheme.typography.bodySmall, color = colors.onSurfaceVariant
                                    )
                                }
                                if (selectedTrack?.uri == track.uri && isPlaying) {
                                    Icon(Icons.Default.VolumeUp, null, tint = colors.primary)
                                } else if (tab == LibraryTab.Tracks) {
                                    IconButton(onClick = {
                                        val c = getController()
                                        if (c != null) {
                                            c.setMediaItems(tracks.map { it.toMediaItem() }, tracks.indexOf(track), 0L)
                                            c.prepare(); c.play()
                                            selectedTrack = track
                                        }
                                    }) { Icon(Icons.Default.PlayArrow, "Воспроизвести") }
                                }
                            }
                            HorizontalDivider(color = colors.outlineVariant.copy(alpha = 0.35f))
                        }
                    }
                }
                // Compact player always visible.
                Surface(
                    color = colors.surface,
                    shape = RoundedCornerShape(18.dp),
                    modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp)
                ) {
                    Column(Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(shape = RoundedCornerShape(10.dp), color = colors.background, modifier = Modifier.size(48.dp)) {
                                Box(contentAlignment = Alignment.Center) { Icon(Icons.Default.Album, null, tint = colors.onSurfaceVariant) }
                            }
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(selectedTrack?.title ?: "Ничего не играет", maxLines = 1, fontWeight = FontWeight.Medium)
                                Text(selectedTrack?.artist ?: "Выбери альбом или трек", maxLines = 1, style = MaterialTheme.typography.bodySmall, color = colors.onSurfaceVariant)
                            }
                            IconButton(onClick = { getController()?.seekToPreviousMediaItem() }, enabled = getController()?.mediaItemCount ?: 0 > 0) {
                                Icon(Icons.Default.SkipPrevious, "Предыдущий трек")
                            }
                            IconButton(onClick = {
                                val c = getController()
                                if (c != null) {
                                    if (c.isPlaying) c.pause() else {
                                        if (c.mediaItemCount == 0 && tracks.isNotEmpty()) {
                                            c.setMediaItems(tracks.map { it.toMediaItem() })
                                            c.prepare()
                                        }
                                        c.play()
                                    }
                                }
                            }) {
                                Icon(if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, if (isPlaying) "Пауза" else "Воспроизвести")
                            }
                            IconButton(onClick = { getController()?.seekToNextMediaItem() }, enabled = (getController()?.mediaItemCount ?: 0) > 0) {
                                Icon(Icons.Default.SkipNext, "Следующий трек")
                            }
                        }
                        Slider(
                            value = if (duration > 0) position.coerceAtMost(duration).toFloat() else 0f,
                            onValueChange = { position = it.toLong() },
                            onValueChangeFinished = { getController()?.seekTo(position) },
                            valueRange = 0f..(duration.coerceAtLeast(1L)).toFloat(),
                            enabled = duration > 0
                        )
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(formatTime(position), style = MaterialTheme.typography.labelSmall, color = colors.onSurfaceVariant)
                            Text(formatTime(duration), style = MaterialTheme.typography.labelSmall, color = colors.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }
}

private fun formatTime(ms: Long): String {
    val total = (ms.coerceAtLeast(0L) / 1000).toInt()
    return "%d:%02d".format(total / 60, total % 60)
}
