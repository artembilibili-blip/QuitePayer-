# Quiet Player — Android prototype

Minimal local Android music player prototype built with Kotlin, Jetpack Compose and AndroidX Media3.

## Features in this prototype
- Choose one folder using Android's system folder picker; read permission is persisted.
- Scan audio files in that folder and its subfolders.
- Browse albums, artists and tracks.
- Light and dark themes.
- Background playback through MediaSessionService, with system playback controls.
- Common audio formats supported by the device/Media3 codecs.

## Build APK in GitHub Actions
The repository includes `.github/workflows/android.yml`. After pushing the project to the `main` branch, open the repository's **Actions** tab, select **Build Quiet Player APK**, and run the workflow if it has not started automatically. When it finishes, open the run and download the `QuietPlayer-debug-apk` artifact.

The workflow uses Java 17 and Gradle 8.9. It builds a debug APK at `app/build/outputs/apk/debug/app-debug.apk`.

## Important
This is an initial prototype, not a tested release. It has not yet been verified on a physical device. Actual format support depends on Android/Media3 codecs. Album artwork and further polish are not included yet.
